package com.cos.mediAPI.medigerplus.medigerplusModel;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class medigerplusMypageList {
	String itemImage;
	String itemName;
	Long itemSeq;
}
