package com.cos.mediAPI.medigerplus.medigerplusModel;

public enum eatTime {
	beforeMeal,
	afterMeal,
	Meal
}
