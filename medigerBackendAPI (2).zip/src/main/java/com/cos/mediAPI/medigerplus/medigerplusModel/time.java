package com.cos.mediAPI.medigerplus.medigerplusModel;

public enum time {
	Morn,
	After,
	Even
}
