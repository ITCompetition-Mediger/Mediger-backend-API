package com.cos.mediAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedigerBackendApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
