///**
// * 
// */
//package com.cos.mediAPI.login2;
//
//import lombok.Getter;
//
///**
// * @author muddie
// *
// */
//@Getter
//public enum ProviderType {
//    GOOGLE,
//    FACEBOOK,
//    NAVER,
//    KAKAO
//}
