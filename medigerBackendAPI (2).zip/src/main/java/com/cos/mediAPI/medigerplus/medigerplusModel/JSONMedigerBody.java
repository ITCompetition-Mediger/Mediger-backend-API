package com.cos.mediAPI.medigerplus.medigerplusModel;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.RequestParam;

public class JSONMedigerBody {
	String ItemName;
	@DateTimeFormat(pattern = "yyyy-MM-dd") 
	LocalDate SD;
	@DateTimeFormat(pattern = "yyyy-MM-dd") 
	LocalDate LD;
	eatTime how;
	int many;
	time T;
	public String getItemName() {
		return ItemName;
	}
	public void setItemName(String itemName) {
		ItemName = itemName;
	}
	public LocalDate getSD() {
		return SD;
	}
	public void setSD(LocalDate sD) {
		SD = sD;
	}
	public LocalDate getLD() {
		return LD;
	}
	public void setLD(LocalDate lD) {
		LD = lD;
	}
	public eatTime getHow() {
		return how;
	}
	public void setHow(eatTime how) {
		this.how = how;
	}
	public int getMany() {
		return many;
	}
	public void setMany(int many) {
		this.many = many;
	}
	public time getT() {
		return T;
	}
	public void setT(time t) {
		T = t;
	}

}
