//package com.cos.mediAPI.login2;
//
//public class UsernameFromTokenException extends RuntimeException{
//    public UsernameFromTokenException(String message){
//        super(message);
//    }
//}