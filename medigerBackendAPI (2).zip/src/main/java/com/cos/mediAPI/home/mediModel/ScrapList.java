package com.cos.mediAPI.home.mediModel;

public interface ScrapList {
	String getItemName();
	String setItemName(String IName);
	Long getItemSeq();
	Long setItemSeq(Long ISeq);
}
