package com.cos.mediAPI.home.mediModel;



 //bean생성자
public interface drugSearchList {
	String getItemImage();
	String getItemName();
	String setItemName(String IName);
	Long getItemSeq();
	Long setItemSeq(Long ISeq);
	String getEntpName();
	String setEntpName(String EName);
}
